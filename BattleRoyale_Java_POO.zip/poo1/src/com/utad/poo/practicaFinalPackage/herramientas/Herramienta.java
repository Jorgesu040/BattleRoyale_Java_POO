package com.utad.poo.practicaFinalPackage.herramientas;


public interface Herramienta
{

	public static String DEFAULT_NOMBRE = "Nueva Herramienta";
	
	public String getNombre();
	public void setNombre(String nombre);
	
}
