package com.utad.poo.practicaFinalPackage.interfazGrafica;

import javax.swing.JButton;
import com.utad.poo.practicaFinalPackage.personajes.Personaje;

public class MoveButton extends JButton {
    public MoveButton(Personaje personaje) {
        super("Moverse");
    }

}
