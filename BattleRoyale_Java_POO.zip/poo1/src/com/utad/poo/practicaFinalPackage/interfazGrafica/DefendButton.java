package com.utad.poo.practicaFinalPackage.interfazGrafica;

import javax.swing.JButton;

import com.utad.poo.practicaFinalPackage.personajes.Personaje;

public class DefendButton extends JButton {
    public DefendButton(Personaje personaje) {
        super("Defensa");
    }
}
