package com.utad.poo.practicaFinalPackage.interfazGrafica;

import javax.swing.JButton;

import com.utad.poo.practicaFinalPackage.personajes.Personaje;

public class RetreatButton extends JButton {
    public RetreatButton(Personaje personaje) {
        super("Retirada");
    }
}

