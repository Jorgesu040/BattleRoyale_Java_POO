package com.utad.poo.practicaFinalPackage.interfazGrafica;

public enum TileType 
{
	TILE_FREE_SPACE,
	TILE_OBSTACLE,
	TILE_LOOT,
	TILE_SPAWN,
	TILE_SPAWN_AI,
	TILE_TRAP_IDLE,
	TILE_TRAP_SET,
	TILE_TRAP_EXPLODED
}
