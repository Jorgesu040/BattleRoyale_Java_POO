package com.utad.poo.practicaFinalPackage.interfazGrafica;

public interface TileEventListener {
    void onTileClicked(Tile tile);
    void onTileHovered(Tile tile);
}