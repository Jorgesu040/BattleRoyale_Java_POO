package com.utad.poo.practicaFinalPackage.interfazGrafica;

import javax.swing.JButton;

public class StartTurnoButton extends JButton {

    public StartTurnoButton() {
        super("Empezar Turno");
    }
                

}
