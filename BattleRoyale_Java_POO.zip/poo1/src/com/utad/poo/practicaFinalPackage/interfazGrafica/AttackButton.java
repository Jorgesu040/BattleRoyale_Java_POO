package com.utad.poo.practicaFinalPackage.interfazGrafica;

import javax.swing.JButton;

import com.utad.poo.practicaFinalPackage.personajes.Personaje;

public class AttackButton extends JButton {
    public AttackButton( Personaje personaje) {
        super("Atacar");
    }
}

