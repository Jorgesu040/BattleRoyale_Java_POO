package com.utad.poo.practicaFinalPackage.partida;

public interface EmpezarTurnoEventListener {
    void onExecuteTurn();
}