package com.utad.poo.practicaFinalPackage.partida;

import com.utad.poo.practicaFinalPackage.interfazGrafica.Tile;

public interface TileClickListener {
    void onTileClicked(Tile tile);
}