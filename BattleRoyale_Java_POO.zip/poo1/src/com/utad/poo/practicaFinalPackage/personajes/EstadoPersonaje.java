package com.utad.poo.practicaFinalPackage.personajes;

public enum EstadoPersonaje {
    NADA,
    ATACANDO,
    DEFENDIENDO,
    RETIRANDOSE,
    MOVIENDOSE
}
